package com.benaether.rxon.rx;

import com.benaether.rxon.core.BackgroundConfig;

public final class RxLog {

    private RxLog() {
    }

    public static void e(String tag, String message, Throwable throwable) {
        Logger log = BackgroundConfig.getLogger();
        if (!BackgroundConfig.isDebug()) {
            log.e(tag, message, throwable);
            return;
        }

        Throwable root = findRootCause(throwable);
        log.e(
                tag,
                message,
                root
        );
    }

    public static void w(String tag, String message, Throwable throwable) {
        Logger log = BackgroundConfig.getLogger();
        if (!BackgroundConfig.isDebug()) {
            log.w(tag, message, throwable);
            return;
        }

        Throwable root = findRootCause(throwable);
        log.w(
                tag,
                message,
                root
        );
    }

    public static void i(String tag, String message) {
        BackgroundConfig.getLogger().i(tag, message);
    }

    public static void d(String tag, String message) {
        BackgroundConfig.getLogger().d(tag, message);
    }

    private static Throwable findRootCause(Throwable throwable) {
        if (throwable == null) return null;

        Throwable current = throwable;
        while (current.getCause() != null
                && !(current.getCause() instanceof hu.akarnokd.rxjava3.debug.RxJavaAssemblyException)) {
            current = current.getCause();
        }
        return current;
    }
}

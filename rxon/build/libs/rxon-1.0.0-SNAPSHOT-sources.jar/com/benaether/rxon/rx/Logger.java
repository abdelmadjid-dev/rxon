package com.benaether.rxon.rx;

public interface Logger {
    void e(String tag, String message, Throwable t);
    void w(String tag, String message, Throwable t);
    void i(String tag, String message);
    void d(String tag, String message);
}

package com.benaether.rxon.rx;

public class DefaultLogger implements Logger {
    @Override
    public void e(String tag, String msg, Throwable t) {
        System.err.println("[" + tag + "] ERROR: " + msg);
        if (t != null) t.printStackTrace();
    }

    @Override
    public void w(String tag, String msg, Throwable t) {
        System.out.println("[" + tag + "] WARN: " + msg);
        if (t != null) t.printStackTrace();
    }

    @Override
    public void i(String tag, String msg) {
        System.out.println("[" + tag + "] INFO: " + msg);
    }

    @Override
    public void d(String tag, String msg) {
        System.out.println("[" + tag + "] DEBUG: " + msg);
    }
}

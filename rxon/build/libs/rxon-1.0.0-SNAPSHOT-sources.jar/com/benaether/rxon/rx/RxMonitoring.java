package com.benaether.rxon.rx;

import com.benaether.rxon.core.BackgroundConfig;

import hu.akarnokd.rxjava3.debug.RxJavaAssemblyTracking;
import io.reactivex.rxjava3.plugins.RxJavaPlugins;

public final class RxMonitoring {
    private static final String TAG = RxMonitoring.class.getName();
    private static final long SLOW_TASK_MS = 100;

    private RxMonitoring() {}

    public static void init() {
        if (!BackgroundConfig.isDebug()) {
            return;
        }

        // Enable assembly tracking with the extensions library
        RxJavaAssemblyTracking.enable();

        // Global error handler
        RxJavaPlugins.setErrorHandler(throwable -> {
            BackgroundConfig.getLogger().e(TAG, "Unhandled RxJava error", throwable);
        });

        // Monitor slow tasks
        RxJavaPlugins.setScheduleHandler(runnable -> () -> {
            long start = System.currentTimeMillis();
            try {
                runnable.run();
            } finally {
                long end = System.currentTimeMillis();
                long duration = end - start;

                if (duration > SLOW_TASK_MS) {
                    BackgroundConfig.getLogger().w(
                            TAG,
                            "Scheduled task took " + duration + " ms on thread "
                                    + Thread.currentThread().getName(),
                            null
                    );
                }
            }
        });
    }


}

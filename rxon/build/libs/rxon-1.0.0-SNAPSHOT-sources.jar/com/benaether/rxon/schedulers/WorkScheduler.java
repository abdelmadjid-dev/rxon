package com.benaether.rxon.schedulers;

public enum WorkScheduler {
    DATA_READ,
    DATA_WRITE,
    IO,
    COMPUTE,
    MAIN
}

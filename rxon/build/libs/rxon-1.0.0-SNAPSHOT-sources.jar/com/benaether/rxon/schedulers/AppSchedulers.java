package com.benaether.rxon.schedulers;

import java.util.concurrent.*;
import io.reactivex.rxjava3.core.Scheduler;
import io.reactivex.rxjava3.schedulers.Schedulers;

public final class AppSchedulers {
    private AppSchedulers() {}

    private static class DataWriteHolder {
        private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "data-write");
            t.setPriority(Thread.NORM_PRIORITY);
            return t;
        });
        static final Scheduler SCHEDULER = Schedulers.from(EXECUTOR);
    }

    private static class DataReadHolder {
        private static final int THREADS = Math.min(3, Math.max(2, Runtime.getRuntime().availableProcessors() / 2));
        private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(THREADS, r -> {
            Thread t = new Thread(r, "data-read");
            t.setPriority(Thread.NORM_PRIORITY);
            return t;
        });
        static final Scheduler SCHEDULER = Schedulers.from(EXECUTOR);
    }

    private static class IoHolder {
        private static final int THREADS = Math.max(2, Runtime.getRuntime().availableProcessors());
        private static final ExecutorService EXECUTOR = new ThreadPoolExecutor(
                THREADS, THREADS, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(),
                r -> {
                    Thread t = new Thread(r, "io-thread");
                    t.setPriority(Thread.NORM_PRIORITY);
                    return t;
                }
        );
        static final Scheduler SCHEDULER = Schedulers.from(EXECUTOR);
    }

    private static class ComputeHolder {
        private static final int CPU = Runtime.getRuntime().availableProcessors();
        private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(
                Math.max(1, CPU - 1),
                r -> {
                    Thread t = new Thread(r, "compute-thread");
                    t.setPriority(Thread.NORM_PRIORITY);
                    return t;
                }
        );
        static final Scheduler SCHEDULER = Schedulers.from(EXECUTOR);
    }

    public static Scheduler dataWrite() { return DataWriteHolder.SCHEDULER; }
    public static Scheduler dataRead() { return DataReadHolder.SCHEDULER; }
    public static Scheduler io() { return IoHolder.SCHEDULER; }
    public static Scheduler compute() { return ComputeHolder.SCHEDULER; }
    public static Scheduler main() { return Schedulers.trampoline(); }
}

package com.benaether.rxon.core;

import com.benaether.rxon.schedulers.WorkScheduler;

import io.reactivex.rxjava3.core.Scheduler;

final class SchedulerResolver {

    private SchedulerResolver() {}

    static Scheduler resolve(WorkScheduler scheduler) {
        return BackgroundConfig.getScheduler(scheduler);
    }
}

package com.benaether.rxon.core;

@FunctionalInterface
public interface ErrorMapper {
    Throwable map(Throwable throwable);
}

package com.benaether.rxon.core;

import com.benaether.rxon.rx.DefaultLogger;
import com.benaether.rxon.rx.Logger;
import com.benaether.rxon.rx.RxMonitoring;
import com.benaether.rxon.schedulers.AppSchedulers;
import com.benaether.rxon.schedulers.WorkScheduler;

import java.util.EnumMap;
import java.util.Map;

import io.reactivex.rxjava3.core.Scheduler;

public final class BackgroundConfig {
    private static ErrorMapper errorMapper = t -> t;
    private static final Map<WorkScheduler, Scheduler> customSchedulers =
            new EnumMap<>(WorkScheduler.class);
    private static boolean debug = false;
    private static Logger logger = new DefaultLogger();

    private BackgroundConfig() {
        RxMonitoring.init();
    }

    public static void setDebug(boolean isDebug) {
        debug = isDebug;
    }

    public static void setLogger(Logger appLogger) {
        logger = appLogger;
    }

    public static void setErrorMapper(ErrorMapper mapper) {
        errorMapper = mapper;
    }

    public static void setScheduler(WorkScheduler type, Scheduler scheduler) {
        customSchedulers.put(type, scheduler);
    }

    public static Throwable mapError(Throwable t) {
        return errorMapper.map(t);
    }

    public static boolean isDebug() { return debug; }

    public static Logger getLogger() { return logger; }

    public static Scheduler getScheduler(WorkScheduler type) {
        return customSchedulers.computeIfAbsent(type, t -> switch (t) {
            case DATA_READ -> AppSchedulers.dataRead();
            case DATA_WRITE -> AppSchedulers.dataWrite();
            case IO -> AppSchedulers.io();
            case COMPUTE -> AppSchedulers.compute();
            case MAIN -> AppSchedulers.main();
        });
    }
}

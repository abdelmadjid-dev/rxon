package com.benaether.rxon.scopes;

import org.reactivestreams.Publisher;

import io.reactivex.rxjava3.core.Completable;
import io.reactivex.rxjava3.core.Single;

public class ScopedBoundaries {
    // =========================
    // ASYNC EXTERNAL (flatMap)
    // =========================

    @FunctionalInterface
    public interface AsyncScope<T, R> {
        Single<R> apply(T t);
    }

    @FunctionalInterface
    public interface AsyncCompletableScope<T> {
        Completable apply(T t);
    }

    // =========================
    // ASYNC EXTERNAL — ZERO INPUT
    // =========================

    public interface AsyncScope0<R> {
        Single<R> apply();
    }

    // =========================
    // STREAM ASYNC BOUNDARIES
    // =========================

    @FunctionalInterface
    public interface StreamAsyncScope<T, R> {
        Publisher<R> apply(T t);
    }

}

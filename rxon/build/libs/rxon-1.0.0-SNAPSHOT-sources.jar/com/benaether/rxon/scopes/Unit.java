package com.benaether.rxon.scopes;

import androidx.annotation.NonNull;

/**
 * Represents the absence of a meaningful value.
 *
 * <p>Use {@code Unit} instead of {@code Void} or {@code null}.
 */
public final class Unit {

    public static final Unit INSTANCE = new Unit();

    private Unit() {}

    @NonNull
    @Override
    public String toString() {
        return "Unit";
    }
}

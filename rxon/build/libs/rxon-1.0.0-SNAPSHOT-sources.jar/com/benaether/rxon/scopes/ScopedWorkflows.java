package com.benaether.rxon.scopes;

import com.benaether.rxon.core.Stream;
import com.benaether.rxon.core.Work;

public final class ScopedWorkflows {

    private ScopedWorkflows() {}

    // ===========================================================================================
    // GENERIC WORKFLOWS (USED BY Work)
    // ===========================================================================================

    @FunctionalInterface
    public interface Workflow<I, O> {
        Work<O> apply(I input);
    }

    @FunctionalInterface
    public interface Workflow0<O> {
        Work<O> apply();
    }

    // ===========================================================================================
    // STREAM WORKFLOWS (USED BY Stream)
    // ===========================================================================================

    @FunctionalInterface
    public interface StreamWorkflow<I, O> {
        Stream<O> apply(I input);
    }

    @FunctionalInterface
    public interface StreamWorkflow0<O> {
        Stream<O> apply();
    }
}

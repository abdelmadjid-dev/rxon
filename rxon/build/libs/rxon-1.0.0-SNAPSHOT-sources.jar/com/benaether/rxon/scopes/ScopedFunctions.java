package com.benaether.rxon.scopes;

import io.reactivex.rxjava3.functions.Function;

public class ScopedFunctions {


    @FunctionalInterface
    public interface ThrowingFn<T, R> extends Function<T, R> {
        R apply(T t) throws Exception;
    }

    @FunctionalInterface
    public interface ThrowingUnitFn<T> {
        void apply(T t) throws Exception;
    }

}
